
class UserCredentials {
  String email;
  String password;

  UserCredentials({
    required this.email,
    required this.password
  });
}
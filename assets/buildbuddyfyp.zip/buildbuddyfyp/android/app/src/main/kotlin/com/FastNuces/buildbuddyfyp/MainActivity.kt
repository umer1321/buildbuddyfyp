package com.FastNuces.buildbuddyfyp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
